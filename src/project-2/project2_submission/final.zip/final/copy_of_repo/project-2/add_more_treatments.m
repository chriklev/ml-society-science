load ("generating_matrices.mat");
X = load ("data/medical/historical_X.dat");
A = load ("data/medical/historical_A.dat");
Y = load ("data/medical/historical_Y.dat");
